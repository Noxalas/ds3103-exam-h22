namespace ElectricGamesApi.Interfaces;
public interface IAbility
{
    int Id { get; set; }
    string Name { get; set; }
    string IconImagePath { get; set; }
}