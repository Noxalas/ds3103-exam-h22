import ContactPage from "./ContactPage";
import HomePage from "./HomePage";
import QuizPage from "./QuizPage";
import EditPage from "./EditPage";
import CreateNewPage from "./CreateNewPage";

export { ContactPage, HomePage, QuizPage, EditPage, CreateNewPage };
