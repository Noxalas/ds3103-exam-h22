const QuizPage = () => {
  return (
    <section>
      <h1>This is our quiz... or atleast we thought it would be</h1>
    </section>
  );
};

export default QuizPage;
