interface ICharacter {
  id?: number;
  name: string;
}

export default ICharacter;
