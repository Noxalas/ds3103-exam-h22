interface IGame {
  id?: number;
  title: string;
  platform: string;
  releaseYear: number;
  image: string;
}

export default IGame;
